﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double num1, num2;

            if ((double.TryParse(txt1.Text, out num1)) && (double.TryParse(txt2.Text, out num2)))
            {
                if (num1 == 0 || num2 == 0)
                    MessageBox.Show("O Cubo não tem volume!");

                else
                {
                    //Poderia fazer o PI com função math.PI()
                    //Poderia fazer o RAIO quadrado com função math.POW(raio,2)

                    //Funções para bloquear textBox
                    //enable false - Não da para copiar e focar
                    //read only - aceita focar e copiar

                    double volume = (num1*num1*num2*3.14);
                    txt3.Text = volume.ToString("N2");
                }
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txt1.Clear();
            txt2.Clear();
            txt3.Clear();
        }

        private void txt2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
